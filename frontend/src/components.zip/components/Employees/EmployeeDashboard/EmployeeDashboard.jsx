import React from "react";
import "./EmployeeDashboard.css";

const EmployeeDashboard = () => {
  return (
    <>
      <h1>Hi Employee</h1>
    </>
  );
};

export default EmployeeDashboard;
