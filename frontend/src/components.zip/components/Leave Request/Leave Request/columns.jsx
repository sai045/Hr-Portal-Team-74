export const COLUMNS = [
  {
    Header: "Id",
    accessor: "id",
  },
  {
    Header: "Employee Name",
    accessor: "Employee_Name",
  },
  {
    Header: "Leave Date",
    accessor: "Leave_Date",
  },
  {
    Header: "Days",
    accessor: "Days",
  },
];
