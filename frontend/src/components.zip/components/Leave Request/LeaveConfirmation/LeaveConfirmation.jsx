import React from "react";

const LeaveConfirmation = () => {
  return (
    <div>
      <h1>Hi</h1>
    </div>
  );
};

export default LeaveConfirmation;