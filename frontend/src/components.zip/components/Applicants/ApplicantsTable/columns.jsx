export const COLUMNS = [
  {
    Header: "Name",
    accessor: "name",
  },
  {
    Header: "Qualification",
    accessor: "qualification",
  },
  {
    Header: "Experience",
    accessor: "experience",
  },
  {
    Header: "Position",
    accessor: "position",
  },
];
