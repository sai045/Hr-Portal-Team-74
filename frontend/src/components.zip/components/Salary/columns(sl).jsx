export const COLUMNS = [
  {
    Header: "Department",
    accessor: "department",
  },
  {
    Header: "Count",
    accessor: "count",
  },
  {
    Header: "Annual Pay",
    accessor: "amount",
  },
];
