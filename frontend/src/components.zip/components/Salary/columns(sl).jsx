export const COLUMNS = [
  {
    Header: "Department",
    accessor: "department",
  },
  {
    Header: "Annual Pay",
    accessor: "salary",
  },
];
