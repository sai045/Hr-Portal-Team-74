import React from "react";
import "./Announcements.css";

const resumeHandler = (event) => {
  window.location.href = `/`;
};

const Announcements = () =>{
    return (
      <div className="divhead">
        <marquee width="100%" direction="down" height="500px">
          <h1 className="heading">
            This feature will be implemented soon...⏰
          </h1>
        </marquee>
        <button className="homebtn" onClick={resumeHandler}>
          Go back to home
        </button>
      </div>
    );
}
export default Announcements;