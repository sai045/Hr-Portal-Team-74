import React from "react";

const TravelConfirmation = () => {
  return (
    <div>
      <h1>Hi</h1>
    </div>
  );
};

export default TravelConfirmation;
